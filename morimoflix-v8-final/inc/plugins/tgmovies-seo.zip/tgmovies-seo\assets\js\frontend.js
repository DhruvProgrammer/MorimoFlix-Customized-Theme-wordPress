/* TGMovies SEO - rating widget (vanilla JS, no jQuery). */
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.tg-rating').forEach(function (box) {
        var postId = box.getAttribute('data-post');
        box.querySelectorAll('.tg-star').forEach(function (star) {
            star.addEventListener('click', function () {
                var v = star.getAttribute('data-v');
                var body = new FormData();
                body.append('action', 'tg_vote');
                body.append('nonce', (window.tgRating && window.tgRating.nonce) || '');
                body.append('post_id', postId);
                body.append('rating', v);
                fetch((window.tgRating && window.tgRating.ajaxUrl) || '/wp-admin/admin-ajax.php', {
                    method: 'POST',
                    credentials: 'same-origin',
                    body: body
                })
                    .then(function (r) { return r.json(); })
                    .then(function (res) {
                        var meta = box.querySelector('.tg-rating-meta');
                        if (res.success && meta) {
                            meta.textContent = '★ ' + res.data.avg + ' (' + res.data.count + ')';
                        } else if (meta && res.data && res.data.message) {
                            meta.textContent = res.data.message;
                        }
                    });
            });
        });
    });
});
