<?php
/**
 * M5 — Instant Indexing (Google Indexing API).
 *
 * @package TGMovies_SEO
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class TG_SEO_Indexing {

    protected static $instance = null;
    const CAP = 200;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_action( 'transition_post_status', array( $this, 'on_publish' ), 30, 3 );
        add_action( 'tgmovies_seo_daily', array( $this, 'drain_queue' ) );
    }

    public function on_publish( $new, $old, $post ) {
        if ( 'publish' !== $new || 'movie' !== $post->post_type ) {
            return;
        }
        $this->submit( get_permalink( $post ) );
    }

    /**
     * Submit a URL (or queue when key missing / cap reached).
     *
     * @param string $url URL.
     */
    public function submit( $url ) {
        $key_json = TGMovies_SEO::setting( 'google_indexing_key' );
        if ( empty( $key_json ) ) {
            $this->log( $url, 'queued-no-key' );
            $this->queue( $url );
            return;
        }
        $today = gmdate( 'Y-m-d' );
        $log   = get_option( 'wp_tg_indexing_log', array() );
        $used  = isset( $log[ $today ] ) ? absint( $log[ $today ] ) : 0;
        if ( $used >= self::CAP ) {
            $this->queue( $url );
            return;
        }
        $key = json_decode( $key_json, true );
        if ( empty( $key['client_email'] ) || empty( $key['private_key'] ) ) {
            $this->log( $url, 'bad-key' );
            return;
        }
        $token = $this->access_token( $key );
        if ( ! $token ) {
            $this->queue( $url );
            return;
        }
        $res = wp_remote_post(
            'https://indexing.googleapis.com/v3/urlNotifications:publish',
            array(
                'timeout'  => 15,
                'blocking' => false,
                'headers'  => array(
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer ' . $token,
                ),
                'body'     => wp_json_encode( array( 'url' => $url, 'type' => 'URL_UPDATED' ) ),
            )
        );
        if ( ! is_wp_error( $res ) ) {
            $log[ $today ] = $used + 1;
            update_option( 'wp_tg_indexing_log', $log, false );
            $this->log( $url, 'sent' );
        } else {
            $this->queue( $url );
        }
    }

    /**
     * Minimal JWT access token for the service account.
     *
     * @param array $key Service account JSON.
     * @return string|false
     */
    protected function access_token( $key ) {
        // phpcs:ignore -- minimal JWT, no external lib per spec (no Composer).
        $b64 = function ( $d ) {
            return rtrim( strtr( base64_encode( $d ), '+/', '-_' ), '=' );
        };
        $now     = time();
        $header  = $b64( wp_json_encode( array( 'alg' => 'RS256', 'typ' => 'JWT' ) ) );
        $payload = $b64(
            wp_json_encode(
                array(
                    'iss'   => $key['client_email'],
                    'scope' => 'https://www.googleapis.com/auth/indexing',
                    'aud'   => 'https://oauth2.googleapis.com/token',
                    'iat'   => $now,
                    'exp'   => $now + 3600,
                )
            )
        );
        $sig = '';
        $pkey = openssl_pkey_get_private( $key['private_key'] );
        if ( ! $pkey ) {
            return false;
        }
        openssl_sign( $header . '.' . $payload, $sig, $pkey, OPENSSL_ALGO_SHA256 );
        $jwt = $header . '.' . $payload . '.' . $b64( $sig );
        $res = wp_remote_post(
            'https://oauth2.googleapis.com/token',
            array(
                'timeout' => 15,
                'body'    => array(
                    'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                    'assertion'  => $jwt,
                ),
            )
        );
        if ( is_wp_error( $res ) ) {
            return false;
        }
        $body = json_decode( wp_remote_retrieve_body( $res ), true );
        return isset( $body['access_token'] ) ? $body['access_token'] : false;
    }

    protected function queue( $url ) {
        $q = get_option( 'wp_tg_indexing_queue', array() );
        if ( ! in_array( $url, $q, true ) ) {
            $q[] = $url;
            update_option( 'wp_tg_indexing_queue', array_slice( $q, -500 ), false );
        }
    }

    public function drain_queue() {
        $q = get_option( 'wp_tg_indexing_queue', array() );
        if ( empty( $q ) ) {
            return;
        }
        update_option( 'wp_tg_indexing_queue', array(), false );
        foreach ( array_slice( $q, 0, self::CAP ) as $url ) {
            $this->submit( $url );
        }
    }

    protected function log( $url, $status ) {
        $log   = get_option( 'wp_tg_indexing_detail', array() );
        $log[] = array( 'time' => current_time( 'mysql' ), 'url' => substr( $url, 0, 200 ), 'status' => $status );
        update_option( 'wp_tg_indexing_detail', array_slice( $log, -200 ), false );
    }
}
