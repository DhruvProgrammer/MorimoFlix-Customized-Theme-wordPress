<?php
/**
 * Plugin Name:       TGMovies SEO
 * Plugin URI:        https://tgmovies.morimoflix.xyz/tgmovies-seo
 * Description:       Movie-specific SEO companion to Rank Math. Auto-enriches movies from TMDB, auto-generates visible SEO blocks, manages real user ratings, auto internal links, instant indexing, health dashboard, llms.txt. No external AI services required.
 * Version:           0.1.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            MorimoFlix
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       tgmovies-seo
 * Domain Path:       /languages
 *
 * @package TGMovies_SEO
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'TGMOVIES_SEO_VERSION', '0.1.0' );
define( 'TGMOVIES_SEO_PATH', plugin_dir_path( __FILE__ ) );
define( 'TGMOVIES_SEO_URL', plugin_dir_url( __FILE__ ) );

require_once TGMOVIES_SEO_PATH . 'includes/class-tg-seo.php';
require_once TGMOVIES_SEO_PATH . 'includes/class-tg-autoseo.php';
require_once TGMOVIES_SEO_PATH . 'includes/class-tg-tmdb.php';
require_once TGMOVIES_SEO_PATH . 'includes/class-tg-internal-links.php';
require_once TGMOVIES_SEO_PATH . 'includes/class-tg-ratings.php';
require_once TGMOVIES_SEO_PATH . 'includes/class-tg-indexing.php';
require_once TGMOVIES_SEO_PATH . 'includes/class-tg-llms.php';
require_once TGMOVIES_SEO_PATH . 'includes/class-tg-health.php';
require_once TGMOVIES_SEO_PATH . 'includes/class-tg-images.php';
require_once TGMOVIES_SEO_PATH . 'includes/class-tg-schema.php';
require_once TGMOVIES_SEO_PATH . 'includes/class-tg-admin.php';

register_activation_hook( __FILE__, array( 'TGMovies_SEO', 'on_activate' ) );
register_deactivation_hook( __FILE__, array( 'TGMovies_SEO', 'on_deactivate' ) );

add_action( 'plugins_loaded', array( 'TGMovies_SEO', 'instance' ) );
