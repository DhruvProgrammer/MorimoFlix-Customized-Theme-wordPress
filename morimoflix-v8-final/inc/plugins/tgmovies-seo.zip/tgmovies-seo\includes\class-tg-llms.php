<?php
/**
 * M7 — llms.txt Generator (daily, physical file at site root).
 *
 * @package TGMovies_SEO
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class TG_SEO_LLMS {

    protected static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_action( 'tgmovies_seo_daily', array( $this, 'generate' ) );
    }

    /**
     * Build and write /llms.txt via WP_Filesystem.
     *
     * @return bool
     */
    public function generate() {
        global $wp_filesystem;
        require_once ABSPATH . 'wp-admin/includes/file.php';
        if ( ! WP_Filesystem() || empty( $wp_filesystem ) || ! is_object( $wp_filesystem ) ) {
            TGMovies_SEO::log_error( 'llms.txt skipped: filesystem unavailable' );
            return false;
        }
        if ( 'direct' !== $wp_filesystem->method ) {
            TGMovies_SEO::log_error( 'llms.txt skipped: filesystem method is not direct' );
            return false;
        }

        $lines   = array();
        $lines[] = '# ' . get_bloginfo( 'name' );
        $lines[] = '> ' . get_bloginfo( 'description' );
        $lines[] = '';
        $lines[] = '## Main categories';
        $genres = get_terms( array( 'taxonomy' => 'genre', 'hide_empty' => false ) );
        if ( ! is_wp_error( $genres ) && ! empty( $genres ) ) {
            foreach ( $genres as $g ) {
                if ( absint( $g->count ) < 5 ) {
                    continue;
                }
                $g_link = get_term_link( $g );
                if ( is_wp_error( $g_link ) ) {
                    continue;
                }
                $lines[] = '- [' . $g->name . ' Movies](' . $g_link . ') — ' . absint( $g->count ) . ' titles';
            }
        }
        $lines[] = '';
        $langs = get_terms( array( 'taxonomy' => 'language', 'hide_empty' => false ) );
        if ( ! is_wp_error( $langs ) && ! empty( $langs ) ) {
            $lines[] = '## Languages';
            foreach ( $langs as $l ) {
                $l_link = get_term_link( $l );
                if ( is_wp_error( $l_link ) ) {
                    continue;
                }
                $lines[] = '- [' . $l->name . '](' . $l_link . ') — ' . absint( $l->count ) . ' titles';
            }
            $lines[] = '';
        }
        $lines[] = '## How to request a movie';
        $lines[] = TGMovies_SEO::setting( 'request_text', '' );
        $lines[] = '';
        $lines[] = '## Last updated';
        $lines[] = gmdate( 'Y-m-d' );
        $lines[] = '';

        $content = implode( "\n", $lines );
        if ( ! $wp_filesystem->put_contents( ABSPATH . 'llms.txt', $content, FS_CHMOD_FILE ) ) {
            TGMovies_SEO::log_error( 'llms.txt write failed (permissions)' );
            add_action(
                'admin_notices',
                function () {
                    echo '<div class="notice notice-error"><p>' . esc_html__( 'TGMovies SEO: could not write llms.txt — check file permissions.', 'tgmovies-seo' ) . '</p></div>';
                }
            );
            return false;
        }
        return true;
    }
}
