<?php
/**
 * M1 — TMDB Content Engine.
 *
 * @package TGMovies_SEO
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class TG_SEO_TMDB {

    protected static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_action( 'save_post_movie', array( $this, 'maybe_enrich' ), 20, 2 );
        add_filter( 'bulk_actions-edit-movie', array( $this, 'bulk_label' ) );
        add_filter( 'handle_bulk_actions-edit-movie', array( $this, 'bulk_enrich' ), 10, 3 );
    }

    /**
     * Enrich on save unless already enriched.
     *
     * @param int     $post_id Post ID.
     * @param WP_Post $post Post object.
     */
    public function maybe_enrich( $post_id, $post ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        if ( wp_is_post_revision( $post_id ) ) {
            return;
        }
        if ( 'publish' !== $post->post_status && 'draft' !== $post->post_status ) {
            return;
        }
        if ( get_post_meta( $post_id, '_tg_enriched', true ) ) {
            return;
        }
        $this->enrich( $post_id, $post->post_title );
    }

    /**
     * Fetch TMDB search + details + credits, store in custom table.
     *
     * @param int    $post_id Post ID.
     * @param string $title Movie title.
     * @return bool
     */
    public function enrich( $post_id, $title ) {
        $key = TGMovies_SEO::setting( 'tmdb_api_key' );
        if ( empty( $key ) || empty( $title ) ) {
            return false;
        }
        $search = wp_remote_get(
            add_query_arg(
                array( 'api_key' => $key, 'query' => $title ),
                'https://api.themoviedb.org/3/search/movie'
            ),
            array( 'timeout' => 15 )
        );
        if ( is_wp_error( $search ) || 200 !== wp_remote_retrieve_response_code( $search ) ) {
            TGMovies_SEO::log_error( 'TMDB search failed for post ' . $post_id );
            return false;
        }
        $data = json_decode( wp_remote_retrieve_body( $search ), true );
        if ( empty( $data['results'][0]['id'] ) ) {
            return false;
        }
        $tmdb_id = absint( $data['results'][0]['id'] );

        $detail = wp_remote_get(
            add_query_arg( array( 'api_key' => $key ), 'https://api.themoviedb.org/3/movie/' . $tmdb_id ),
            array( 'timeout' => 15 )
        );
        $credits = wp_remote_get(
            add_query_arg( array( 'api_key' => $key ), 'https://api.themoviedb.org/3/movie/' . $tmdb_id . '/credits' ),
            array( 'timeout' => 15 )
        );
        $info = is_wp_error( $detail ) ? array() : (array) json_decode( wp_remote_retrieve_body( $detail ), true );
        $cast = array();
        if ( ! is_wp_error( $credits ) ) {
            $cdata = json_decode( wp_remote_retrieve_body( $credits ), true );
            if ( ! empty( $cdata['cast'] ) && is_array( $cdata['cast'] ) ) {
                foreach ( array_slice( $cdata['cast'], 0, 10 ) as $c ) {
                    if ( ! empty( $c['name'] ) ) {
                        $cast[] = sanitize_text_field( $c['name'] );
                    }
                }
            }
        }

        global $wpdb;
        $t = TGMovies_SEO::tables();
        $wpdb->replace(
            $t['meta'],
            array(
                'post_id'          => $post_id,
                'tmdb_id'          => $tmdb_id,
                'plot_original'    => isset( $info['overview'] ) ? wp_kses_post( $info['overview'] ) : '',
                'last_enriched_at' => current_time( 'mysql' ),
            ),
            array( '%d', '%d', '%s', '%s' )
        );
        if ( ! empty( $info['runtime'] ) ) {
            update_post_meta( $post_id, '_movie_duration', absint( $info['runtime'] ) . 'M' );
        }
        if ( ! empty( $cast ) ) {
            update_post_meta( $post_id, '_tmdb_cast', $cast );
        }
        update_post_meta( $post_id, '_tg_enriched', 1 );
        return true;
    }

    public function bulk_label( $actions ) {
        $actions['tg_reenrich'] = __( 'Re-enrich from TMDB', 'tgmovies-seo' );
        return $actions;
    }

    public function bulk_enrich( $redirect, $action, $ids ) {
        if ( 'tg_reenrich' !== $action ) {
            return $redirect;
        }
        $done = 0;
        foreach ( wp_parse_id_list( $ids ) as $id ) {
            if ( ! current_user_can( 'edit_post', $id ) ) {
                continue;
            }
            delete_post_meta( $id, '_tg_enriched' );
            if ( $this->enrich( $id, get_the_title( $id ) ) ) {
                $done++;
            }
        }
        return add_query_arg( 'tg_reenriched', $done, $redirect );
    }
}
