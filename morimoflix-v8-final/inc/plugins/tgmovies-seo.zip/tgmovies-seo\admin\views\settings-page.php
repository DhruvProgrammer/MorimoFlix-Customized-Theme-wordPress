<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap tg-seo-wrap">
    <h1><?php esc_html_e( 'TGMovies SEO Settings', 'tgmovies-seo' ); ?></h1>
    <?php
    $tg_idx_log   = get_option( 'wp_tg_indexing_log', array() );
    $tg_idx_today = isset( $tg_idx_log[ gmdate( 'Y-m-d' ) ] ) ? absint( $tg_idx_log[ gmdate( 'Y-m-d' ) ] ) : 0;
    $tg_idx_queue = get_option( 'wp_tg_indexing_queue', array() );
    $tg_idx_last  = array_slice( array_reverse( (array) get_option( 'wp_tg_indexing_detail', array() ) ), 0, 5 );
    ?>
    <div class="tg-seo-card" style="max-width:640px;margin-bottom:16px;">
        <h2 style="margin-top:0;"><?php esc_html_e( 'Instant Indexing status', 'tgmovies-seo' ); ?></h2>
        <p><?php echo esc_html( sprintf( __( 'Sent today: %d / 200 · Queued: %d', 'tgmovies-seo' ), $tg_idx_today, count( $tg_idx_queue ) ) ); ?></p>
        <?php if ( ! empty( $tg_idx_last ) ) : ?>
        <ul>
            <?php foreach ( $tg_idx_last as $e ) : ?>
            <li><code><?php echo esc_html( $e['status'] ?? '' ); ?></code> — <?php echo esc_html( $e['url'] ?? '' ); ?> <span style="color:#646970;">(<?php echo esc_html( $e['time'] ?? '' ); ?>)</span></li>
            <?php endforeach; ?>
        </ul>
        <?php else : ?>
        <p style="color:#646970;"><?php esc_html_e( 'No submissions yet — publish or update a movie to trigger one.', 'tgmovies-seo' ); ?></p>
        <?php endif; ?>
    </div>
    <form method="post" action="options.php">
        <?php settings_fields( 'tgmovies_seo' ); ?>
        <?php $o = get_option( 'tgmovies_seo_settings', array() ); ?>
        <table class="form-table">
            <tr>
                <th><label for="tg_tmdb"><?php esc_html_e( 'TMDB API Key', 'tgmovies-seo' ); ?></label></th>
                <td><input type="password" id="tg_tmdb" name="tgmovies_seo_settings[tmdb_api_key]" value="<?php echo esc_attr( $o['tmdb_api_key'] ?? '' ); ?>" class="regular-text" autocomplete="off"></td>
            </tr>
            <tr>
                <th><label for="tg_idx"><?php esc_html_e( 'Google Indexing Key (service account JSON)', 'tgmovies-seo' ); ?></label></th>
                <td><textarea id="tg_idx" name="tgmovies_seo_settings[google_indexing_key]" rows="5" cols="50" class="large-text code"><?php echo esc_textarea( $o['google_indexing_key'] ?? '' ); ?></textarea></td>
            </tr>
            <tr>
                <th><label for="tg_tg"><?php esc_html_e( 'Telegram Channel URL', 'tgmovies-seo' ); ?></label></th>
                <td><input type="url" id="tg_tg" name="tgmovies_seo_settings[telegram_url]" value="<?php echo esc_attr( $o['telegram_url'] ?? '' ); ?>" class="regular-text"></td>
            </tr>
            <tr>
                <th><label for="tg_req"><?php esc_html_e( 'Request-a-movie text (llms.txt)', 'tgmovies-seo' ); ?></label></th>
                <td><textarea id="tg_req" name="tgmovies_seo_settings[request_text]" rows="3" cols="50" class="large-text"><?php echo esc_textarea( $o['request_text'] ?? '' ); ?></textarea></td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Toggles', 'tgmovies-seo' ); ?></th>
                <td>
                    <label><input type="checkbox" name="tgmovies_seo_settings[internal_links_enabled]" value="1" <?php checked( $o['internal_links_enabled'] ?? 1, 1 ); ?>> <?php esc_html_e( 'Auto internal links', 'tgmovies-seo' ); ?></label><br>
                    <label><input type="checkbox" name="tgmovies_seo_settings[lazy_load_default]" value="1" <?php checked( $o['lazy_load_default'] ?? 1, 1 ); ?>> <?php esc_html_e( 'Lazy-load images', 'tgmovies-seo' ); ?></label><br>
                    <label><input type="checkbox" name="tgmovies_seo_settings[webp_enabled]" value="1" <?php checked( $o['webp_enabled'] ?? 1, 1 ); ?>> <?php esc_html_e( 'Generate WebP copies', 'tgmovies-seo' ); ?></label><br>
                    <label><input type="checkbox" name="tgmovies_seo_settings[uninstall_consent]" value="1" <?php checked( $o['uninstall_consent'] ?? 0, 1 ); ?>> <?php esc_html_e( 'Delete all data on uninstall', 'tgmovies-seo' ); ?></label>
                </td>
            </tr>
        </table>
        <?php submit_button(); ?>
    </form>
</div>
