<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="tg-rating" data-post="<?php echo absint( $post_id ); ?>">
    <div class="tg-stars" role="radiogroup" aria-label="<?php esc_attr_e( 'Rate this movie', 'tgmovies-seo' ); ?>">
        <?php for ( $i = 1; $i <= 5; $i++ ) : ?>
            <button type="button" class="tg-star" data-v="<?php echo esc_attr( $i ); ?>" aria-label="<?php echo esc_attr( sprintf( __( '%d stars', 'tgmovies-seo' ), $i ) ); ?>">★</button>
        <?php endfor; ?>
    </div>
    <p class="tg-rating-meta">
        <?php if ( $count > 0 ) : ?>
            <?php echo esc_html( sprintf( __( '★ %s (%d votes)', 'tgmovies-seo' ), $avg, $count ) ); ?>
        <?php else : ?>
            <?php esc_html_e( 'Be the first to rate', 'tgmovies-seo' ); ?>
        <?php endif; ?>
    </p>
</div>
