=== TGMovies SEO ===
Contributors: morimoflix
Tags: seo, movies, tmdb, ratings, internal links
Requires at least: 6.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 0.1.0
License: GPL-2.0-or-later

Movie-specific SEO companion to Rank Math. TMDB enrichment, automatic SEO blocks, real user ratings, auto internal links, instant indexing, health dashboard, llms.txt, image pipeline. Fully automatic — no AI services required.

== Description ==

TGMovies SEO adds movie-specific SEO capabilities Rank Math cannot provide: TMDB auto-enrichment, automatic visible SEO blocks with focus-keyword auto-set, real user-submitted ratings that replace hardcoded aggregateRating, contextual internal linking, Google Indexing API submissions, a health dashboard (404s, broken links, orphans, thin content, E-E-A-T), daily llms.txt generation, and a WebP + lazy-load image pipeline. Everything except TMDB/Indexing keys works with zero configuration.

== Installation ==

1. Install via Appearance → Install Plugins (TGM prompt from the MorimoFlix theme), or upload this folder to wp-content/plugins/ and Activate.
2. Go to Settings → TGMovies SEO and enter your TMDB API key (optional — focus keywords and SEO blocks work without any keys).
3. Paste a Google service-account JSON key to enable Instant Indexing (optional).
4. Visit Tools → TGMovies SEO Health to see your scores.

== Frequently Asked Questions ==

= Does this replace Rank Math? =
No. It is a companion. Rank Math keeps titles, sitemaps and base schema; this plugin adds movie-specific modules and replaces the hardcoded aggregateRating with real votes via the rank_math/json_ld filter.

= Will switching themes delete my data? =
No. All data lives in custom tables (wp_tg_*) and options. Deactivation preserves data; uninstall drops tables only if you tick the consent box.

== Changelog ==

= 0.1.0 =
* Initial release: M1-M8 modules, settings, health dashboard, TGM bundling.
