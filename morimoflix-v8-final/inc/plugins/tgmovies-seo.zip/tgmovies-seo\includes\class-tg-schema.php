<?php
/**
 * Schema repairs: Organization sameAs (broken Telegram) + llms.txt entity link.
 *
 * @package TGMovies_SEO
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class TG_SEO_Schema {

    protected static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_filter( 'rank_math/json_ld', array( $this, 'fix_organization' ), 10, 2 );
    }

    /**
     * Swap the known-broken Telegram URL in Organization.sameAs for the
     * configured one, and append /llms.txt as an entity reference.
     *
     * @param array  $data Rank Math schema data.
     * @param string $type Schema type.
     * @return array
     */
    public function fix_organization( $data, $type ) {
        $telegram = TGMovies_SEO::setting( 'telegram_url', 'https://t.me/MorimoFlix_Zone' );
        $walk = function ( &$node ) use ( &$walk, $telegram ) {
            if ( ! is_array( $node ) ) {
                return;
            }
            if ( isset( $node['@type'] ) && 'Organization' === $node['@type'] && isset( $node['sameAs'] ) && is_array( $node['sameAs'] ) ) {
                foreach ( $node['sameAs'] as $i => $url ) {
                    if ( false !== strpos( $url, 't.me/MorimoFlix_Zone' ) && $url !== $telegram ) {
                        $node['sameAs'][ $i ] = $telegram;
                    }
                }
                if ( ! in_array( home_url( '/llms.txt' ), $node['sameAs'], true ) ) {
                    $node['sameAs'][] = home_url( '/llms.txt' );
                }
            }
            foreach ( $node as &$child ) {
                $walk( $child );
            }
        };
        $walk( $data );
        return $data;
    }
}
