<?php
/**
 * M6 — Health Dashboard (Tools page).
 *
 * @package TGMovies_SEO
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class TG_SEO_Health {

    protected static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_action( 'admin_menu', array( $this, 'menu' ) );
        add_action( 'template_redirect', array( $this, 'log_404' ) );
        add_action( 'tgmovies_seo_hourly', array( $this, 'scan_broken' ) );
    }

    public function menu() {
        add_management_page(
            __( 'TGMovies SEO Health', 'tgmovies-seo' ),
            __( 'TGMovies SEO Health', 'tgmovies-seo' ),
            'manage_options',
            'tgmovies-seo-health',
            array( $this, 'page' )
        );
    }

    public function page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $data = $this->collect();
        include TGMOVIES_SEO_PATH . 'admin/views/health-page.php';
    }

    /**
     * Log 404 request URIs.
     */
    public function log_404() {
        if ( ! is_404() ) {
            return;
        }
        $uri = esc_url_raw( $_SERVER['REQUEST_URI'] ?? '/' );
        $log = get_option( 'wp_tg_404_log', array() );
        $log[] = array( 'time' => current_time( 'mysql' ), 'uri' => substr( $uri, 0, 255 ) );
        update_option( 'wp_tg_404_log', array_slice( $log, -200 ), false );
    }

    /**
     * Hourly: HEAD-check external links found in movie posts.
     */
    public function scan_broken() {
        $posts = get_posts( array( 'post_type' => 'movie', 'posts_per_page' => 20, 'fields' => 'ids' ) );
        $bad   = get_option( 'wp_tg_broken_log', array() );
        foreach ( $posts as $id ) {
            $content = get_post_field( 'post_content', $id );
            preg_match_all( '/href="(https?:\/\/[^"]+)"/i', $content, $m );
            foreach ( array_slice( array_unique( $m[1] ), 0, 5 ) as $url ) {
                if ( false !== strpos( $url, home_url() ) ) {
                    continue;
                }
                $res  = wp_remote_head( $url, array( 'timeout' => 5 ) );
                $code = is_wp_error( $res ) ? 0 : absint( wp_remote_retrieve_response_code( $res ) );
                if ( 0 === $code || $code >= 400 ) {
                    $bad[] = array( 'time' => current_time( 'mysql' ), 'url' => substr( $url, 0, 255 ), 'code' => $code );
                }
            }
        }
        update_option( 'wp_tg_broken_log', array_slice( $bad, -200 ), false );
    }

    /**
     * Collect all health metrics.
     *
     * @return array
     */
    public function collect() {
        $movie_ids = get_posts( array( 'post_type' => 'movie', 'posts_per_page' => -1, 'fields' => 'ids' ) );
        $thin      = 0;
        $no_out    = 0;
        $eeat_sum  = 0;

        foreach ( $movie_ids as $id ) {
            $content = get_post_field( 'post_content', $id );
            $words   = str_word_count( wp_strip_all_tags( $content ) );
            if ( $words < 250 ) {
                $thin++;
            }
            $has_out = (bool) preg_match( '/href="https?:\/\//i', $content );
            $has_in  = false !== strpos( $content, home_url() );
            if ( ! $has_in ) {
                $no_out++;
            }
            $score = 0;
            if ( get_the_author_meta( 'display_name', get_post_field( 'post_author', $id ) ) ) {
                $score += 20;
            }
            if ( get_the_modified_date( 'U', $id ) > get_the_date( 'U', $id ) ) {
                $score += 20;
            }
            if ( $has_in ) {
                $score += 20;
            }
            if ( $has_out ) {
                $score += 20;
            }
            if ( has_post_thumbnail( $id ) ) {
                $score += 20;
            }
            $eeat_sum += $score;
        }

        $fours = get_option( 'wp_tg_404_log', array() );
        $recent_404 = 0;
        foreach ( $fours as $f ) {
            if ( strtotime( $f['time'] ) > time() - 7 * DAY_IN_SECONDS ) {
                $recent_404++;
            }
        }

        return array(
            'movies'   => count( $movie_ids ),
            'thin'     => $thin,
            'orphans'  => $no_out,
            'fours'    => $recent_404,
            'broken'   => get_option( 'wp_tg_broken_log', array() ),
            'eeat_avg' => $movie_ids ? round( $eeat_sum / count( $movie_ids ), 1 ) : 0,
        );
    }
}
