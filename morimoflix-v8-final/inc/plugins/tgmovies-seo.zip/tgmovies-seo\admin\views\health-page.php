<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap tg-seo-wrap">
    <h1><?php esc_html_e( 'TGMovies SEO Health', 'tgmovies-seo' ); ?></h1>
    <p><?php echo esc_html( sprintf( __( 'Movies: %d · Avg E-E-A-T: %s/100', 'tgmovies-seo' ), $data['movies'], $data['eeat_avg'] ) ); ?></p>
    <div class="tg-seo-cards">
        <div class="tg-seo-card"><h2><?php echo absint( $data['fours'] ); ?></h2><p><?php esc_html_e( '404s (7 days)', 'tgmovies-seo' ); ?></p></div>
        <div class="tg-seo-card"><h2><?php echo count( $data['broken'] ); ?></h2><p><?php esc_html_e( 'Broken externals', 'tgmovies-seo' ); ?></p><a href="#tg-broken"><?php esc_html_e( 'View details', 'tgmovies-seo' ); ?></a></div>
        <div class="tg-seo-card"><h2><?php echo absint( $data['orphans'] ); ?></h2><p><?php esc_html_e( 'No outgoing internal links', 'tgmovies-seo' ); ?></p></div>
        <div class="tg-seo-card"><h2><?php echo absint( $data['thin'] ); ?></h2><p><?php esc_html_e( 'Thin content (<250 words)', 'tgmovies-seo' ); ?></p></div>
    </div>
    <h2 id="tg-broken"><?php esc_html_e( 'Broken external links', 'tgmovies-seo' ); ?></h2>
    <?php if ( empty( $data['broken'] ) ) : ?>
        <p><?php esc_html_e( 'None found in the last scan.', 'tgmovies-seo' ); ?></p>
    <?php else : ?>
        <table class="widefat striped">
            <thead><tr><th><?php esc_html_e( 'Time', 'tgmovies-seo' ); ?></th><th><?php esc_html_e( 'URL', 'tgmovies-seo' ); ?></th><th><?php esc_html_e( 'Code', 'tgmovies-seo' ); ?></th></tr></thead>
            <tbody>
            <?php foreach ( array_slice( array_reverse( $data['broken'] ), 0, 50 ) as $b ) : ?>
                <tr><td><?php echo esc_html( $b['time'] ); ?></td><td><a href="<?php echo esc_url( $b['url'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $b['url'] ); ?></a></td><td><?php echo absint( $b['code'] ); ?></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
