<?php
/**
 * M8 — Image Pipeline (WebP + lazy attrs).
 *
 * @package TGMovies_SEO
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class TG_SEO_Images {

    protected static $instance = null;
    protected static $hero_done = false;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_filter( 'wp_generate_attachment_metadata', array( $this, 'webp_copies' ), 10, 2 );
        add_filter( 'wp_get_attachment_image_attributes', array( $this, 'attrs' ), 10, 3 );
        add_filter( 'the_content', array( $this, 'content_lazy' ), 20 );
    }

    /**
     * Generate WebP copies of each resized image (GD only, silent fail).
     *
     * @param array $meta Attachment metadata.
     * @param int   $id Attachment ID.
     * @return array
     */
    public function webp_copies( $meta, $id ) {
        if ( ! TGMovies_SEO::setting( 'webp_enabled', 1 ) ) {
            return $meta;
        }
        if ( ! function_exists( 'imagewebp' ) || empty( $meta['sizes'] ) ) {
            return $meta;
        }
        $dir = trailingslashit( dirname( get_attached_file( $id ) ) );
        foreach ( $meta['sizes'] as $size ) {
            $src = $dir . $size['file'];
            if ( '.webp' === strtolower( substr( $src, -5 ) ) ) {
                continue;
            }
            $img = wp_get_image_editor( $src );
            if ( is_wp_error( $img ) ) {
                continue;
            }
            $img->save( $src . '.webp', 'image/webp' );
        }
        return $meta;
    }

    /**
     * Inject loading/decoding/fetchpriority attributes.
     *
     * @param array   $attr Attributes.
     * @param WP_Post $att Attachment.
     * @param string  $size Size.
     * @return array
     */
    public function attrs( $attr, $att, $size ) {
        if ( ! empty( $attr['data-critical'] ) ) {
            $attr['fetchpriority'] = 'high';
            $attr['loading']       = 'eager';
            return $attr;
        }
        if ( TGMovies_SEO::setting( 'lazy_load_default', 1 ) ) {
            if ( empty( $attr['loading'] ) ) {
                $attr['loading'] = 'lazy';
            }
            if ( empty( $attr['decoding'] ) ) {
                $attr['decoding'] = 'async';
            }
        }
        // First poster in the homepage carousel is the LCP image.
        if ( ( is_front_page() || is_home() ) && ! self::$hero_done && in_the_loop() ) {
            self::$hero_done       = true;
            $attr['fetchpriority'] = 'high';
            $attr['loading']       = 'eager';
        }
        return $attr;
    }

    /**
     * Idempotent lazy-load injection for content images.
     *
     * @param string $content Content.
     * @return string
     */
    public function content_lazy( $content ) {
        if ( ! TGMovies_SEO::setting( 'lazy_load_default', 1 ) ) {
            return $content;
        }
        return preg_replace_callback(
            '/<img(?![^>]*loading=)([^>]*)>/i',
            function ( $m ) {
                return '<img loading="lazy" decoding="async"' . $m[1] . '>';
            },
            $content
        );
    }
}
