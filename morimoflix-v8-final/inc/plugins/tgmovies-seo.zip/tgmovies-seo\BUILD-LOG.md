# TGMovies SEO — Build Log (v0.1.0)

Standalone source: `theme/tgmovies-seo/` (source of truth — edit here)
TGMPA library: `morimoflix-v8-final/inc/tgm/class-tgm-plugin-activation.php` (v2.6.1, upstream)
Shippable zip (built artifact for TGM): `morimoflix-v8-final/inc/plugins/tgmovies-seo.zip`
  Rebuild after any plugin change: from `theme/` run
  `Compress-Archive -Path "tgmovies-seo" -DestinationPath "morimoflix-v8-final\inc\plugins\tgmovies-seo.zip" -Force`
Theme wiring: `functions.php` → `morimoflix_register_required_plugins()` on `tgmpa_register` (source path unchanged)

## Modules

| Module | File | Public methods | Notes |
|---|---|---|---|
| Core | `includes/class-tg-seo.php` | `instance()`, `setting()`, `tables()`, `on_activate()`, `on_deactivate()`, `log_error()` | Creates `wp_tg_movie_meta`, `wp_tg_ratings`, `wp_tg_link_graph` via dbDelta; schedules daily/hourly/weekly crons |
| M1 TMDB | `includes/class-tg-tmdb.php` | `maybe_enrich()`, `enrich()`, `bulk_enrich()` | `save_post_movie` @20, skips when `_tg_enriched`; stores tmdb_id/plot/runtime/cast |
| AutoSEO | `includes/class-tg-autoseo.php` | `maybe_autoseo()`, `set_focus_keyword()`, `generate()`, `build_block()` | Focus-keyword auto-set + visible SEO block, zero-config, keyless |
| M3 Links | `includes/class-tg-internal-links.php` | `auto_link()`, `candidates()`, `insert_link()`, `weekly_sweep()` | ≤5 links/post mid-paragraph, tracked in link graph; suggest metabox via admin-post (no AJAX) |
| M4 Ratings | `includes/class-tg-ratings.php` | `widget()`, `vote()`, `inject_rating()` | `[tg_rating]` shortcode; 1 vote per (post, ip_hash); `rank_math/json_ld` filter replaces hardcoded aggregateRating, omits when 0 votes |
| M5 Indexing | `includes/class-tg-indexing.php` | `submit()`, `drain_queue()` | Minimal JWT (openssl, no lib); 200/day cap; queue + detail log options |
| M6 Health | `includes/class-tg-health.php` | `collect()`, `scan_broken()`, `log_404()` | Tools page: 404s/7d, broken externals, orphans, thin, E-E-A-T avg (20pts × 5 rubric) |
| M7 llms.txt | `includes/class-tg-llms.php` | `generate()` | Daily cron; WP_Filesystem write to ABSPATH; genres ≥5 posts + language tax + request text + date |
| M8 Images | `includes/class-tg-images.php` | `webp_copies()`, `attrs()`, `content_lazy()` | GD `imagewebp` copies; lazy/async attrs; LCP fetchpriority on front-page first image |
| Schema | `includes/class-tg-schema.php` | `fix_organization()` | Repairs broken Telegram in Organization.sameAs → configured URL; appends /llms.txt |
| Admin | `includes/class-tg-admin.php` | `sanitize()`, `page()` | Single `tgmovies_seo_settings` option (§8 fields); vanilla JS only |

## Decisions / deviations

- TGM `source` points at the shippable zip (private distribution). For WordPress.org review, upload via Plugins screen instead.
- Theme keeps its own virtual `/llms.txt` + JSON-LD; plugin writes the physical file and filters Rank Math only (no theme edits beyond TGM wiring).
- `request_text` and `telegram_url` settings exist but the theme hardcodes its Telegram links — swap those after the owner supplies the working URL (audit 1.3/4.8).
- PHP 7.4-safe: no arrow fns, no `str_contains`/`match`, no typed properties. No Composer, no jQuery in admin JS.

## Changelog

### 0.1.1 (unreleased)

- 0.1.1 (unreleased) — AutoSEO module (`includes/class-tg-autoseo.php`, `TG_SEO_AutoSEO`): Rank Math focus keyword auto-set ("Title Year") + visible SEO block (`_tg_autoseo_block`/`_tg_autoseo_done`). Public methods: `instance()`, `hooks()`, `maybe_autoseo()`, `set_focus_keyword()`, `generate()`, `build_block()`, `bulk_label()`, `bulk_generate()`.

- 0.1.0 — Initial bundled release (M1, M3–M8, settings, health, TGM wiring).
- Removed M2 LLM rewriter (`class-tg-rewriter.php`, settings fields, bulk action, admin JS) per owner request — plugin is now fully automatic with no AI services. Remaining keyless modules: AutoSEO, ratings, internal links, health, llms.txt, images, schema.
