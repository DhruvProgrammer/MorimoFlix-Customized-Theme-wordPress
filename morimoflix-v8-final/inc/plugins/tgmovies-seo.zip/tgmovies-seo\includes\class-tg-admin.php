<?php
/**
 * Admin: settings page, assets, notices.
 *
 * @package TGMovies_SEO
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class TG_SEO_Admin {

    protected static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_action( 'admin_menu', array( $this, 'menu' ) );
        add_action( 'admin_init', array( $this, 'register' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
        add_action( 'admin_notices', array( $this, 'bulk_notices' ) );
    }

    public function menu() {
        add_options_page(
            __( 'TGMovies SEO', 'tgmovies-seo' ),
            __( 'TGMovies SEO', 'tgmovies-seo' ),
            'manage_options',
            'tgmovies-seo',
            array( $this, 'page' )
        );
    }

    public function register() {
        register_setting( 'tgmovies_seo', 'tgmovies_seo_settings', array( $this, 'sanitize' ) );
    }

    /**
     * Sanitize the single options array.
     *
     * @param array $in Raw input.
     * @return array
     */
    public function sanitize( $in ) {
        $out = array();
        $out['tmdb_api_key']            = sanitize_text_field( $in['tmdb_api_key'] ?? '' );
        $out['google_indexing_key']     = sanitize_textarea_field( $in['google_indexing_key'] ?? '' );
        $out['internal_links_enabled']  = ! empty( $in['internal_links_enabled'] ) ? 1 : 0;
        $out['lazy_load_default']       = ! empty( $in['lazy_load_default'] ) ? 1 : 0;
        $out['webp_enabled']            = ! empty( $in['webp_enabled'] ) ? 1 : 0;
        $out['telegram_url']            = esc_url_raw( $in['telegram_url'] ?? '' );
        $out['request_text']            = sanitize_textarea_field( $in['request_text'] ?? '' );
        $out['uninstall_consent']       = ! empty( $in['uninstall_consent'] ) ? 1 : 0;
        return $out;
    }

    public function page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        include TGMOVIES_SEO_PATH . 'admin/views/settings-page.php';
    }

    public function assets( $hook ) {
        if ( false === strpos( $hook, 'tgmovies-seo' ) ) {
            return;
        }
        wp_enqueue_style( 'tg-seo-admin', TGMOVIES_SEO_URL . 'assets/css/admin.css', array(), TGMOVIES_SEO_VERSION );
    }

    public function bulk_notices() {
        if ( ! empty( $_GET['tg_reenriched'] ) ) {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( sprintf( __( 'TGMovies SEO: re-enriched %d movies.', 'tgmovies-seo' ), absint( $_GET['tg_reenriched'] ) ) ) . '</p></div>';
        }
        if ( isset( $_GET['tg_autoseo'] ) ) {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( sprintf( __( 'TGMovies SEO: generated %d SEO blocks.', 'tgmovies-seo' ), absint( $_GET['tg_autoseo'] ) ) ) . '</p></div>';
        }
    }
}
