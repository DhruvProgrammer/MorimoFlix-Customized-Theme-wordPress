<?php
/**
 * M4 — Real Ratings Module.
 *
 * @package TGMovies_SEO
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class TG_SEO_Ratings {

    protected static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_shortcode( 'tg_rating', array( $this, 'widget' ) );
        add_action( 'wp_ajax_tg_vote', array( $this, 'vote' ) );
        add_action( 'wp_ajax_nopriv_tg_vote', array( $this, 'vote' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'assets' ) );
        add_filter( 'rank_math/json_ld', array( $this, 'inject_rating' ), 20, 2 );
        add_filter( 'manage_movie_posts_columns', array( $this, 'column' ) );
        add_action( 'manage_movie_posts_custom_column', array( $this, 'column_html' ), 10, 2 );
        add_filter( 'manage_edit-movie_sortable_columns', array( $this, 'sortable' ) );
    }

    public function assets() {
        if ( ! is_singular( 'movie' ) ) {
            return;
        }
        wp_enqueue_script( 'tg-rating', TGMOVIES_SEO_URL . 'assets/js/frontend.js', array(), TGMOVIES_SEO_VERSION, true );
        wp_localize_script(
            'tg-rating',
            'tgRating',
            array(
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'tg_vote' ),
            )
        );
    }

    /**
     * Star widget shortcode for single-movie.php.
     *
     * @return string
     */
    public function widget() {
        $post_id = get_the_ID();
        $avg     = get_post_meta( $post_id, '_tg_real_rating_avg', true );
        $count   = absint( get_post_meta( $post_id, '_tg_real_rating_count', true ) );
        ob_start();
        include TGMOVIES_SEO_PATH . 'admin/views/rating-widget.php';
        return ob_get_clean();
    }

    /**
     * Handle a vote: one per (post, ip_hash).
     */
    public function vote() {
        check_ajax_referer( 'tg_vote', 'nonce' );
        $post_id = absint( $_POST['post_id'] ?? 0 );
        $rating  = absint( $_POST['rating'] ?? 0 );
        if ( ! $post_id || $rating < 1 || $rating > 5 ) {
            wp_send_json_error( array( 'message' => __( 'Invalid vote.', 'tgmovies-seo' ) ) );
        }
        $target = get_post( $post_id );
        if ( ! $target || 'movie' !== $target->post_type || 'publish' !== $target->post_status ) {
            wp_send_json_error( array( 'message' => __( 'Invalid vote.', 'tgmovies-seo' ) ) );
        }
        $ip_hash = wp_hash( $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0' );
        global $wpdb;
        $t = TGMovies_SEO::tables();
        $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t['ratings']} WHERE post_id = %d AND ip_hash = %s", $post_id, $ip_hash ) );
        if ( $exists ) {
            wp_send_json_error( array( 'message' => __( 'You already voted.', 'tgmovies-seo' ) ) );
        }
        $wpdb->insert(
            $t['ratings'],
            array(
                'post_id' => $post_id,
                'user_id' => get_current_user_id(),
                'ip_hash' => $ip_hash,
                'rating'  => $rating,
            ),
            array( '%d', '%d', '%s', '%d' )
        );
        $avg   = $wpdb->get_var( $wpdb->prepare( "SELECT AVG(rating) FROM {$t['ratings']} WHERE post_id = %d", $post_id ) );
        $count = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t['ratings']} WHERE post_id = %d", $post_id ) );
        update_post_meta( $post_id, '_tg_real_rating_avg', round( (float) $avg, 1 ) );
        update_post_meta( $post_id, '_tg_real_rating_count', absint( $count ) );
        wp_send_json_success( array( 'avg' => round( (float) $avg, 1 ), 'count' => absint( $count ) ) );
    }

    /**
     * Replace hardcoded aggregateRating in Rank Math JSON-LD with real votes.
     *
     * @param array  $data Rank Math schema data.
     * @param string $type Schema type.
     * @return array
     */
    public function inject_rating( $data, $type ) {
        if ( ! is_singular( 'movie' ) ) {
            return $data;
        }
        $count = absint( get_post_meta( get_the_ID(), '_tg_real_rating_count', true ) );
        if ( $count < 1 ) {
            // No real votes: omit the property entirely (no fake ratings).
            unset( $data['aggregateRating'] );
            return $data;
        }
        $data['aggregateRating'] = array(
            '@type'       => 'AggregateRating',
            'ratingValue' => get_post_meta( get_the_ID(), '_tg_real_rating_avg', true ),
            'ratingCount' => $count,
            'bestRating'  => '5',
        );
        return $data;
    }

    public function column( $cols ) {
        $cols['tg_rating'] = __( 'Rating', 'tgmovies-seo' );
        return $cols;
    }

    public function column_html( $col, $post_id ) {
        if ( 'tg_rating' !== $col ) {
            return;
        }
        $avg   = get_post_meta( $post_id, '_tg_real_rating_avg', true );
        $count = absint( get_post_meta( $post_id, '_tg_real_rating_count', true ) );
        echo $count > 0 ? esc_html( '★ ' . $avg . ' (' . $count . ')' ) : '—';
    }

    public function sortable( $cols ) {
        $cols['tg_rating'] = 'tg_rating';
        return $cols;
    }
}
