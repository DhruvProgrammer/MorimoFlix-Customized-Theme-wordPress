<?php
/**
 * Uninstall: drop tables + options ONLY with explicit consent.
 *
 * @package TGMovies_SEO
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

$opts = get_option( 'tgmovies_seo_settings', array() );
if ( empty( $opts['uninstall_consent'] ) ) {
    return;
}

global $wpdb;
$tables = array(
    $wpdb->prefix . 'tg_movie_meta',
    $wpdb->prefix . 'tg_ratings',
    $wpdb->prefix . 'tg_link_graph',
);
foreach ( $tables as $table ) {
    $wpdb->query( "DROP TABLE IF EXISTS {$table}" ); // phpcs:ignore
}
delete_option( 'tgmovies_seo_settings' );
delete_option( 'wp_tg_error_log' );
delete_option( 'wp_tg_404_log' );
delete_option( 'wp_tg_broken_log' );
delete_option( 'wp_tg_indexing_log' );
delete_option( 'wp_tg_indexing_queue' );
delete_option( 'wp_tg_indexing_detail' );
