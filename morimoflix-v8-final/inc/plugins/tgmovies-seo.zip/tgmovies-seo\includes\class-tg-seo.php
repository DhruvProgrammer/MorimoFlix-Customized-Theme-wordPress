<?php
/**
 * Core singleton: constants, activation, crons, module loader.
 *
 * @package TGMovies_SEO
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class TGMovies_SEO {

    /**
     * Singleton instance.
     *
     * @var TGMovies_SEO|null
     */
    protected static $instance = null;

    /**
     * Get instance.
     *
     * @return TGMovies_SEO
     */
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->init();
        }
        return self::$instance;
    }

    /**
     * Wire modules.
     */
    public function init() {
        load_plugin_textdomain( 'tgmovies-seo', false, dirname( plugin_basename( __FILE__ ), 2 ) . '/languages' );
        TG_SEO_TMDB::instance();
        TG_SEO_Internal_Links::instance();
        TG_SEO_Ratings::instance();
        TG_SEO_Indexing::instance();
        TG_SEO_LLMS::instance();
        TG_SEO_Health::instance();
        TG_SEO_Images::instance();
        TG_SEO_Schema::instance();
        TG_SEO_AutoSEO::instance();
        if ( is_admin() ) {
            TG_SEO_Admin::instance();
        }
    }

    /**
     * Get a settings value.
     *
     * @param string $key Setting key.
     * @param mixed  $default Default.
     * @return mixed
     */
    public static function setting( $key, $default = '' ) {
        $opts = get_option( 'tgmovies_seo_settings', array() );
        return isset( $opts[ $key ] ) ? $opts[ $key ] : $default;
    }

    /**
     * Table names with prefix.
     *
     * @return array
     */
    public static function tables() {
        global $wpdb;
        return array(
            'meta'    => $wpdb->prefix . 'tg_movie_meta',
            'ratings' => $wpdb->prefix . 'tg_ratings',
            'links'   => $wpdb->prefix . 'tg_link_graph',
        );
    }

    /**
     * Activation: tables, defaults, crons.
     */
    public static function on_activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $t   = self::tables();
        $col = $wpdb->get_charset_collate();

        dbDelta( "CREATE TABLE {$t['meta']} (
            post_id bigint(20) unsigned NOT NULL,
            tmdb_id bigint(20) unsigned DEFAULT 0,
            content_hash varchar(64) DEFAULT '',
            plot_original longtext,
            last_enriched_at datetime DEFAULT NULL,
            PRIMARY KEY (post_id)
        ) $col;" );

        dbDelta( "CREATE TABLE {$t['ratings']} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            post_id bigint(20) unsigned NOT NULL,
            user_id bigint(20) unsigned DEFAULT 0,
            ip_hash varchar(64) NOT NULL,
            rating tinyint(1) unsigned NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY vote (post_id, ip_hash)
        ) $col;" );

        dbDelta( "CREATE TABLE {$t['links']} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            source_post_id bigint(20) unsigned NOT NULL,
            target_post_id bigint(20) unsigned DEFAULT 0,
            target_url varchar(500) DEFAULT '',
            anchor varchar(255) DEFAULT '',
            added_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY pair (source_post_id, target_url(191))
        ) $col;" );

        $defaults = array(
            'tmdb_api_key'           => '',
            'google_indexing_key'    => '',
            'internal_links_enabled' => 1,
            'lazy_load_default'      => 1,
            'webp_enabled'           => 1,
            'telegram_url'           => 'https://t.me/MorimoFlix_Zone',
            'request_text'           => 'Open Request a Movie, fill in the title and year. Added within 24-48 hours.',
            'uninstall_consent'      => 0,
        );
        add_option( 'tgmovies_seo_settings', $defaults );

        if ( ! wp_next_scheduled( 'tgmovies_seo_daily' ) ) {
            wp_schedule_event( strtotime( '03:00:00' ), 'daily', 'tgmovies_seo_daily' );
        }
        if ( ! wp_next_scheduled( 'tgmovies_seo_hourly' ) ) {
            wp_schedule_event( time(), 'hourly', 'tgmovies_seo_hourly' );
        }
        if ( ! wp_next_scheduled( 'tgmovies_seo_weekly' ) ) {
            wp_schedule_event( time(), 'weekly', 'tgmovies_seo_weekly' );
        }
    }

    /**
     * Deactivation: unschedule crons, keep data.
     */
    public static function on_deactivate() {
        wp_clear_scheduled_hook( 'tgmovies_seo_daily' );
        wp_clear_scheduled_hook( 'tgmovies_seo_hourly' );
        wp_clear_scheduled_hook( 'tgmovies_seo_weekly' );
    }

    /**
     * Append to JSON error log option.
     *
     * @param string $message Message.
     */
    public static function log_error( $message ) {
        $log   = get_option( 'wp_tg_error_log', array() );
        $log[] = array( 'time' => current_time( 'mysql' ), 'msg' => substr( $message, 0, 500 ) );
        update_option( 'wp_tg_error_log', array_slice( $log, -100 ), false );
    }
}
