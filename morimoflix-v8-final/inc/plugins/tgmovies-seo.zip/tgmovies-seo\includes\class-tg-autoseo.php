<?php
/**
 * Auto SEO: Rank Math focus keyword + visible SEO block.
 *
 * @package TGMovies_SEO
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class TG_SEO_AutoSEO {

    protected static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_action( 'save_post_movie', array( $this, 'maybe_autoseo' ), 25, 2 );
        add_filter( 'bulk_actions-edit-movie', array( $this, 'bulk_label' ) );
        add_filter( 'handle_bulk_actions-edit-movie', array( $this, 'bulk_generate' ), 10, 3 );
    }

    /**
     * Single-save path: focus keyword + SEO block, once.
     *
     * @param int     $post_id Post ID.
     * @param WP_Post $post    Post object.
     */
    public function maybe_autoseo( $post_id, $post ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        if ( wp_is_post_revision( $post_id ) ) {
            return;
        }
        if ( get_post_meta( $post_id, '_tg_autoseo_done', true ) ) {
            return;
        }
        $this->set_focus_keyword( $post_id, $post );
        $this->generate( $post_id );
    }

    /**
     * Set Rank Math focus keyword to "Title Year" when empty.
     *
     * @param int          $post_id Post ID.
     * @param WP_Post|null $post    Optional post object.
     * @return bool
     */
    public function set_focus_keyword( $post_id, $post = null ) {
        if ( get_post_meta( $post_id, 'rank_math_focus_keyword', true ) ) {
            return false;
        }
        if ( null === $post ) {
            $post = get_post( $post_id );
        }
        if ( ! $post ) {
            return false;
        }
        $title = sanitize_text_field( $post->post_title );
        if ( '' === $title ) {
            return false;
        }
        $year = sanitize_text_field( get_post_meta( $post_id, '_movie_year', true ) );
        if ( '' === $year ) {
            $year = date( 'Y' );
        }
        update_post_meta( $post_id, 'rank_math_focus_keyword', $title . ' ' . $year );
        return true;
    }

    /**
     * Build and store the visible SEO block.
     *
     * @param int $post_id Post ID.
     * @return bool
     */
    public function generate( $post_id ) {
        $html = $this->build_block( $post_id );
        if ( '' === $html ) {
            return false;
        }
        update_post_meta( $post_id, '_tg_autoseo_block', wp_kses_post( $html ) );
        update_post_meta( $post_id, '_tg_autoseo_done', 1 );
        return true;
    }

    /**
     * Build a ~60-90 word visible SEO block from real post data only.
     *
     * @param int $post_id Post ID.
     * @return string
     */
    public function build_block( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post ) {
            return '';
        }
        $title = sanitize_text_field( $post->post_title );
        if ( '' === $title ) {
            return '';
        }
        $year = sanitize_text_field( get_post_meta( $post_id, '_movie_year', true ) );
        if ( '' === $year ) {
            $year = date( 'Y' );
        }
        $lang_raw = get_post_meta( $post_id, '_movie_language', true );
        $lang     = '';
        if ( is_string( $lang_raw ) && '' !== trim( $lang_raw ) ) {
            $parts = explode( ',', $lang_raw );
            $lang  = sanitize_text_field( trim( $parts[0] ) );
        }
        $quality = sanitize_text_field( get_post_meta( $post_id, '_movie_quality', true ) );

        $genre_links = array();
        $genre_names = array();
        $terms       = get_the_terms( $post_id, 'genre' );
        if ( $terms && ! is_wp_error( $terms ) ) {
            foreach ( array_slice( $terms, 0, 2 ) as $term ) {
                $link = get_term_link( $term );
                if ( is_wp_error( $link ) ) {
                    continue;
                }
                $genre_links[] = '<a href="' . esc_url( $link ) . '">' . esc_html( $term->name ) . '</a>';
                $genre_names[] = sanitize_text_field( $term->name );
            }
        }

        $list_url = esc_url( home_url( '/list/' ) );
        $t        = esc_html( $title );
        $y        = esc_html( $year );

        $p1 = 'Watch ' . $t . ' (' . $y . ')';
        if ( '' !== $quality ) {
            $p1 .= ' in ' . esc_html( $quality );
        }
        if ( '' !== $lang ) {
            $p1 .= ' with ' . esc_html( $lang ) . ' audio';
        }
        $p1 .= '.';

        if ( ! empty( $genre_names ) ) {
            $p2 = 'This ' . esc_html( implode( ' / ', $genre_names ) ) . ' feature is listed with its cast, runtime and story details for quick reference before you watch.';
        } else {
            $p2 = 'This feature is listed with its full cast, runtime and story details for quick reference before you watch.';
        }

        $p3 = 'See ' . $t . ' (' . $y . ') streaming and download options on its movie page, then browse more titles in the <a href="' . $list_url . '">A-Z library</a>.';

        if ( ! empty( $genre_links ) ) {
            $p4 = 'Explore more in ' . implode( ' and ', $genre_links ) . '. Cast and crew highlights, runtime and age guidance are shown where available.';
        } else {
            $p4 = 'Full cast and crew highlights, runtime and age guidance are shown where available on this page.';
        }

        return '<p>' . $p1 . ' ' . $p2 . '</p><p>' . $p3 . ' ' . $p4 . '</p>';
    }

    public function bulk_label( $actions ) {
        $actions['tg_autoseo'] = __( 'Generate SEO blocks', 'tgmovies-seo' );
        return $actions;
    }

    public function bulk_generate( $redirect, $action, $ids ) {
        if ( 'tg_autoseo' !== $action ) {
            return $redirect;
        }
        $done = 0;
        foreach ( array_slice( wp_parse_id_list( $ids ), 0, 20 ) as $id ) {
            if ( ! current_user_can( 'edit_post', $id ) ) {
                continue;
            }
            delete_post_meta( $id, '_tg_autoseo_done' );
            $this->set_focus_keyword( $id );
            if ( $this->generate( $id ) ) {
                $done++;
            }
        }
        return add_query_arg( 'tg_autoseo', $done, $redirect );
    }
}
