# TGMovies SEO (v0.1.0)

Movie-specific SEO companion to Rank Math, bundled with the MorimoFlix theme.

## Install

**Via theme (recommended):** Activate the MorimoFlix theme → Appearance → Install Plugins → install + activate **TGMovies SEO** (auto-activates).

**Standalone:** Upload `tgmovies-seo.zip` (or this folder) via Plugins → Add New → Upload → Activate. Works without the theme — all data lives in `wp_tg_*` tables.

## Settings (Settings → TGMovies SEO)

| Field | Purpose |
|---|---|
| TMDB API Key | M1 enrichment on movie save (optional — auto SEO works without it) |
| Google Indexing Key | M5 service-account JSON for Instant Indexing (200/day cap, optional) |
| Telegram Channel URL | Used by M-schema sameAs repair + llms.txt |
| Request-a-movie text | M7 llms.txt section |
| Toggles | Auto internal links, lazy-load, WebP, uninstall consent |

## Usage

- **Enrich:** Movies → bulk actions → Re-enrich from TMDB / Generate SEO blocks. Both run automatically on save — no keys required.
- **Ratings:** add `[tg_rating]` to `single-movie.php` where the widget should render. Votes update `_tg_real_rating_avg/_count` and Rank Math's `aggregateRating` automatically.
- **Health:** Tools → TGMovies SEO Health (404s, broken links, orphans, thin content, E-E-A-T).
- **llms.txt:** generated daily at site root; regenerate by running the `tgmovies_seo_daily` cron (WP Crontrol).

## FAQ

**Does it replace Rank Math?** No — companion only.
**Switch themes safely?** Yes — tables/options preserved; deactivation never drops data.
**Uninstall clean?** Only if you tick "Delete all data on uninstall" first.
