<?php
/**
 * M3 — Internal Link Engine.
 *
 * @package TGMovies_SEO
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class TG_SEO_Internal_Links {

    protected static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_action( 'transition_post_status', array( $this, 'on_publish' ), 20, 3 );
        add_action( 'tgmovies_seo_weekly', array( $this, 'weekly_sweep' ) );
        add_action( 'add_meta_boxes_movie', array( $this, 'metabox' ) );
        add_action( 'admin_post_tg_insert_link', array( $this, 'insert_link' ) );
    }

    public function on_publish( $new, $old, $post ) {
        if ( 'publish' !== $new || 'movie' !== $post->post_type ) {
            return;
        }
        if ( ! TGMovies_SEO::setting( 'internal_links_enabled', 1 ) ) {
            return;
        }
        $this->auto_link( $post->ID );
    }

    /**
     * Insert up to 5 contextual internal links mid-paragraph.
     *
     * @param int $post_id Post ID.
     * @return int Links added.
     */
    public function auto_link( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post ) {
            return 0;
        }
        $targets = $this->candidates( $post_id );
        if ( empty( $targets ) ) {
            return 0;
        }
        $paras = preg_split( '/<\/p>/i', $post->post_content );
        if ( count( $paras ) < 2 ) {
            return 0;
        }
        $added = 0;
        $mid   = (int) floor( count( $paras ) / 2 );
        foreach ( $targets as $anchor => $url ) {
            if ( $added >= 5 || false !== strpos( $post->post_content, $url ) ) {
                continue;
            }
            if ( $this->already_linked( $post_id, $url ) ) {
                continue;
            }
            $link = ' <a href="' . esc_url( $url ) . '">' . esc_html( $anchor ) . '</a>';
            $paras[ $mid ] .= ( 0 === $added % 2 ? $link : '' ) . '';
            if ( 0 !== $added % 2 ) {
                $paras[ max( 0, $mid - 1 ) ] .= $link;
            }
            $this->record( $post_id, 0, $url, $anchor );
            $added++;
        }
        if ( $added > 0 ) {
            remove_action( 'transition_post_status', array( $this, 'on_publish' ), 20 );
            wp_update_post( array( 'ID' => $post_id, 'post_content' => implode( '</p>', $paras ) ) );
            add_action( 'transition_post_status', array( $this, 'on_publish' ), 20, 3 );
        }
        return $added;
    }

    /**
     * Candidate anchor => URL map: genres, languages, lead actors.
     *
     * @param int $post_id Post ID.
     * @return array
     */
    public function candidates( $post_id ) {
        $out = array();
        $genres = get_the_terms( $post_id, 'genre' );
        if ( $genres && ! is_wp_error( $genres ) ) {
            foreach ( array_slice( $genres, 0, 3 ) as $g ) {
                $link = get_term_link( $g );
                if ( ! is_wp_error( $link ) ) {
                    $out[ $g->name . ' movies' ] = $link;
                }
            }
        }
        $cast = get_post_meta( $post_id, '_tmdb_cast', true );
        if ( is_array( $cast ) ) {
            foreach ( array_slice( $cast, 0, 3 ) as $name ) {
                $term = get_term_by( 'name', is_array( $name ) ? ( $name['name'] ?? '' ) : $name, 'actor' );
                if ( $term && ! is_wp_error( $term ) ) {
                    $label = is_array( $name ) ? ( $name['name'] ?? '' ) : $name;
                    $link  = get_term_link( $term );
                    if ( ! is_wp_error( $link ) && '' !== $label ) {
                        $out[ $label ] = $link;
                    }
                }
            }
        }
        $rel = get_posts(
            array(
                'post_type'      => 'movie',
                'posts_per_page' => 3,
                'post__not_in'   => array( $post_id ),
                'fields'         => 'ids',
            )
        );
        foreach ( $rel as $rid ) {
            $out[ get_the_title( $rid ) ] = get_permalink( $rid );
        }
        return array_slice( $out, 0, 10, true );
    }

    protected function already_linked( $source, $url ) {
        global $wpdb;
        $t = TGMovies_SEO::tables();
        return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t['links']} WHERE source_post_id = %d AND target_url = %s", $source, $url ) );
    }

    protected function record( $source, $target, $url, $anchor ) {
        global $wpdb;
        $t = TGMovies_SEO::tables();
        $wpdb->replace(
            $t['links'],
            array(
                'source_post_id' => $source,
                'target_post_id' => $target,
                'target_url'     => substr( $url, 0, 500 ),
                'anchor'         => substr( $anchor, 0, 255 ),
            ),
            array( '%d', '%d', '%s', '%s' )
        );
    }

    public function metabox() {
        add_meta_box( 'tg_link_suggest', __( 'TGMovies Link Suggestions', 'tgmovies-seo' ), array( $this, 'metabox_html' ), 'movie', 'side', 'default' );
    }

    public function metabox_html( $post ) {
        $cands = $this->candidates( $post->ID );
        if ( empty( $cands ) ) {
            echo '<p>' . esc_html__( 'No suggestions yet.', 'tgmovies-seo' ) . '</p>';
            return;
        }
        echo '<ul>';
        foreach ( $cands as $anchor => $url ) {
            $href = add_query_arg(
                array(
                    'action'   => 'tg_insert_link',
                    'post_id'  => $post->ID,
                    'url'      => rawurlencode( $url ),
                    'anchor'   => rawurlencode( $anchor ),
                    '_wpnonce' => wp_create_nonce( 'tg_insert_link' ),
                ),
                admin_url( 'admin-post.php' )
            );
            echo '<li><a href="' . esc_url( $href ) . '">' . esc_html( $anchor ) . '</a></li>';
        }
        echo '</ul>';
    }

    public function insert_link() {
        check_admin_referer( 'tg_insert_link' );
        $post_id = absint( $_GET['post_id'] ?? 0 );
        if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
            wp_die( esc_html__( 'Not allowed.', 'tgmovies-seo' ) );
        }
        $url    = esc_url_raw( wp_unslash( $_GET['url'] ?? '' ) );
        $anchor = sanitize_text_field( wp_unslash( $_GET['anchor'] ?? '' ) );
        if ( $url && $anchor ) {
            $post = get_post( $post_id );
            wp_update_post( array( 'ID' => $post_id, 'post_content' => $post->post_content . ' <a href="' . esc_url( $url ) . '">' . esc_html( $anchor ) . '</a>' ) );
            $this->record( $post_id, 0, $url, $anchor );
        }
        wp_safe_redirect( get_edit_post_link( $post_id, 'redirect' ) );
        exit;
    }

    /**
     * Weekly: find movies with 0 outgoing internal links and auto-link them.
     */
    public function weekly_sweep() {
        $ids = get_posts( array( 'post_type' => 'movie', 'posts_per_page' => 50, 'fields' => 'ids' ) );
        foreach ( $ids as $id ) {
            $content = get_post_field( 'post_content', $id );
            if ( false === strpos( $content, home_url() ) ) {
                $this->auto_link( $id );
            }
        }
    }
}
